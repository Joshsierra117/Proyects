# ControlDeGimnasio
 Proyecto de ingeniería de software para el control del gimnasio VO2MAX
