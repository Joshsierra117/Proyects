﻿using System;

namespace Modelo {
    public class Class1 {
    }
}
