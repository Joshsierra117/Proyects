﻿
namespace ControlDeGimnasio {
    partial class frmMain {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing) {
            if (disposing && (components != null)) {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent() {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(frmMain));
            this.button4 = new System.Windows.Forms.Button();
            this.button3 = new System.Windows.Forms.Button();
            this.button2 = new System.Windows.Forms.Button();
            this.btnOfertas = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // button4
            // 
            this.button4.Image = global::ControlDeGimnasio.Properties.Resources._493ea17829d3f4730f05df8c80fc1a05;
            this.button4.Location = new System.Drawing.Point(38, 33);
            this.button4.Name = "button4";
            this.button4.Size = new System.Drawing.Size(191, 174);
            this.button4.TabIndex = 3;
            this.button4.UseVisualStyleBackColor = true;
            // 
            // button3
            // 
            this.button3.Image = global::ControlDeGimnasio.Properties.Resources.pngtree_tools_icon_design_vector_png_image_1705775;
            this.button3.Location = new System.Drawing.Point(38, 264);
            this.button3.Name = "button3";
            this.button3.Size = new System.Drawing.Size(191, 174);
            this.button3.TabIndex = 2;
            this.button3.UseVisualStyleBackColor = true;
            // 
            // button2
            // 
            this.button2.Image = global::ControlDeGimnasio.Properties.Resources.free_user_group_icon_296_thumb;
            this.button2.Location = new System.Drawing.Point(287, 33);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(191, 174);
            this.button2.TabIndex = 1;
            this.button2.UseVisualStyleBackColor = true;
            // 
            // btnOfertas
            // 
            this.btnOfertas.Image = global::ControlDeGimnasio.Properties.Resources._14038073941582872993_5121;
            this.btnOfertas.Location = new System.Drawing.Point(287, 264);
            this.btnOfertas.Name = "btnOfertas";
            this.btnOfertas.Size = new System.Drawing.Size(191, 174);
            this.btnOfertas.TabIndex = 0;
            this.btnOfertas.UseVisualStyleBackColor = true;
            // 
            // frmMain
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.DimGray;
            this.ClientSize = new System.Drawing.Size(516, 450);
            this.Controls.Add(this.button4);
            this.Controls.Add(this.button3);
            this.Controls.Add(this.button2);
            this.Controls.Add(this.btnOfertas);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "frmMain";
            this.Text = "Main";
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Button btnOfertas;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.Button button3;
        private System.Windows.Forms.Button button4;
    }
}