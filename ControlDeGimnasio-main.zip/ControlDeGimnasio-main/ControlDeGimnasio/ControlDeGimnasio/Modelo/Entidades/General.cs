﻿namespace ControlDeGimnasio.Modelo.Entidades {
    public enum Acciones { 
        Registrar,
        Actualizar,
        Consultar,
        Busqueda
    }
}